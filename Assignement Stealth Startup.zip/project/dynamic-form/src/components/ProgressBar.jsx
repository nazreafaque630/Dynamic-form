import React from "react";

const ProgressBar = ({ completed, total }) => {
  const percentage = Math.round((completed / total) * 100);
  return (
    <div className="progress-bar">
      <div
        className="progress-bar-fill"
        style={{ width: `${percentage}%` }}
      ></div>
      <span>{`${completed}/${total} completed`}</span>
    </div>
  );
};

export default ProgressBar;
