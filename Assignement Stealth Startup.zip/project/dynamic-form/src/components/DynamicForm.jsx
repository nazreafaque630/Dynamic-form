import React, { useState, useEffect } from "react";
import { mockAPI } from "../mockAPI";
import FormField from "./FormField";
import ProgressBar from "./ProgressBar";
import TableDisplay from "./TableDisplay";

const DynamicForm = () => {
  const [formType, setFormType] = useState("userInfo");
  const [formFields, setFormFields] = useState([]);
  const [formData, setFormData] = useState({});
  const [submittedData, setSubmittedData] = useState([]);
  const [feedbackMessage, setFeedbackMessage] = useState("");

  useEffect(() => {
    setFormFields(mockAPI[formType]?.fields || []);
  }, [formType]);

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmittedData([...submittedData, formData]);
    setFeedbackMessage("Form submitted successfully!");
    setFormData({});
  };

  return (
    <div className="dynamic-form">
      <header>
        <h1>Dynamic Form</h1>
      </header>
      <form onSubmit={handleSubmit}>
        <ProgressBar
          completed={Object.keys(formData).length}
          total={formFields.length}
        />
       
        <div className="form-select">
          <label>Select Form Type:</label>
          <select onChange={(e) => setFormType(e.target.value)}>
            <option value="userInfo">User Information</option>
            <option value="addressInfo">Address Information</option>
            <option value="paymentInfo">Payment Information</option>
          </select>
        </div>
        {formFields.map((field) => (
          <FormField
            key={field.name}
            field={field}
            value={formData[field.name] || ""}
            onChange={handleInputChange}
          />
        ))}
        <button type="submit">Submit</button>
      </form>
      {feedbackMessage && <p className="feedback">{feedbackMessage}</p>}
      <TableDisplay data={submittedData} onDelete={() => {}} onEdit={() => {}} />
    </div>
  );
};

export default DynamicForm;
