import React from "react";

const FormField = ({ field, value, onChange }) => {
  if (field.type === "dropdown") {
    return (
      <div className="form-group">
        <label htmlFor={field.name}>{field.label}</label>
        <select
          id={field.name}
          name={field.name}
          value={value}
          onChange={onChange}
          required={field.required}
        >
          <option value="">Select</option>
          {field.options.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </select>
      </div>
    );
  }

  return (
    <div className="form-group">
      <label htmlFor={field.name}>{field.label}</label>
      <input
        id={field.name}
        name={field.name}
        type={field.type}
        value={value}
        onChange={onChange}
        required={field.required}
      />
    </div>
  );
};

export default FormField;
